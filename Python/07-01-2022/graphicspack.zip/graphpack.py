from graphics import circle,rectangle
from graphics.dgraphics import cuboid,sphere

r=int(input("Enter the radius of circle:"))

circle.areac(r)
circle.peric(r)

l=int(input("Enter the length of rectangle:"))
b=int(input("Enter the breadth of rectangle:"))

rectangle.arear(l,b)
rectangle.perir(l,b)

l1=int(input("Enter the length of cuboid:"))
b1=int(input("Enter the breadth of cuboid:"))
h1=int(input("Enter the height of cuboid:"))

cuboid.areacub(l1,b1,h1)
cuboid.pericub(l1,b1,h1)

r1=int(input("Enter the radius of sphere:"))

sphere.areas(r1)
sphere.peris(r1)
