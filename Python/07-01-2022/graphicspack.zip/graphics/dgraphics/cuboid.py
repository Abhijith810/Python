def areacub(l,b,h):
    a = 2*((l*b) + (b*h) + (h*l))
    print("Area of Cuboid is:", a)


def pericub(l,b,h):
    p = 4*(l+b+h)
    print("Perimeter of Cuboid is:", p)
