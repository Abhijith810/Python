def areas(r):
    a = 4*3.14*r*r
    print("Area of Sphere is:", a)


def peris(r):
    p = 6.2832*r
    print("Perimeter of Sphere is:", p)
