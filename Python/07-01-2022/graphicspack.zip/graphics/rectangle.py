def arear(l,b):
    a=l*b
    print("Area of Rectangle is:",a)
def perir(l,b):
    p=2*(l+b)
    print("Area of Rectangle is:",p)
